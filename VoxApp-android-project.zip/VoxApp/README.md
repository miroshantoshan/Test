# Vox for Android

Open this folder in Android Studio (Koala or newer), wait for Gradle sync, then:
Build > Build Bundle(s) / APK(s) > Build APK(s).
The file appears in app/build/outputs/apk/debug/app-debug.apk. Copy it to the phone and install it
(allow "install unknown apps" for your file manager).

What really works on the phone: voice recognition (tap the orb), open any installed app, volume
(up, down, set %), mute/unmute, brightness, flashlight, Wi-Fi panel, Bluetooth settings, lock screen
(device admin), history, editable name.

Not included: the "Hey Vox" wake word, and any link to a MacBook. "Connected to MacBook" is a fixed
demo label (Config.CONNECTION_LABEL in MainActivity.kt).
