package com.vox.app

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.Bluetooth
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.FlashlightOn
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.VolumeOff
import androidx.compose.material.icons.outlined.VolumeUp
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

object Config {
    // Demo label shown under the greeting. Nothing is actually connected to a Mac.
    const val CONNECTION_LABEL = "Connected to MacBook"
}

private val Cream = Color(0xFFF4EEE2)
private val Ink = Color(0xFF2A2622)
private val Muted = Color(0xFF8A7B65)
private val Sand1 = Color(0xFFEDE3D1)
private val Sand2 = Color(0xFFE3D4BA)
private val Brown = Color(0xFF5A4632)
private val Tan = Color(0xFFA88556)

data class Quick(val id: String, val label: String, val icon: ImageVector)

private val QUICK = listOf(
    Quick("volume", "Volume", Icons.Outlined.VolumeUp),
    Quick("lock", "Lock", Icons.Outlined.Lock),
    Quick("apps", "Apps", Icons.Outlined.Apps),
    Quick("bright", "Brightness", Icons.Outlined.WbSunny),
    Quick("flashlight", "Flashlight", Icons.Outlined.FlashlightOn),
    Quick("mute", "Mute", Icons.Outlined.VolumeOff),
    Quick("wifi", "Wi-Fi", Icons.Outlined.Wifi),
    Quick("bluetooth", "Bluetooth", Icons.Outlined.Bluetooth),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val store = Store(this)
        val commands = Commands(this)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(primary = Brown, onPrimary = Color.White, background = Cream, surface = Color.White)
            ) {
                VoxApp(store, commands)
            }
        }
    }
}

@Composable
fun VoxApp(store: Store, cmd: Commands) {
    val ctx = LocalContext.current
    var tab by remember { mutableStateOf(0) }
    var name by remember { mutableStateOf(store.name) }
    var history by remember { mutableStateOf(store.history()) }
    var listening by remember { mutableStateOf(false) }
    var partial by remember { mutableStateOf("") }
    var said by remember { mutableStateOf("") }
    var results by remember { mutableStateOf(listOf<Action>()) }
    var status by remember { mutableStateOf("") }
    var showApps by remember { mutableStateOf(false) }
    var showBright by remember { mutableStateOf(false) }

    fun finish(s: String, r: List<Action>) {
        said = s
        results = r
        store.add(Entry(System.currentTimeMillis(), s, r.map { it.text }))
        history = store.history()
    }

    val voice = remember {
        VoiceListener(ctx, object : VoiceListener.Callbacks {
            override fun onListening() { listening = true; partial = ""; status = "" }
            override fun onPartial(text: String) { partial = text }
            override fun onFinal(text: String) { finish(text, cmd.run(text)) }
            override fun onError(msg: String) { status = msg }
            override fun onEnd() { listening = false; partial = "" }
        })
    }
    DisposableEffect(Unit) { onDispose { voice.destroy() } }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) voice.start() else status = "Microphone permission is needed"
    }

    fun talk() {
        if (listening) { voice.stop(); return }
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (granted) voice.start() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    fun quick(q: Quick) {
        when (q.id) {
            "apps" -> showApps = true
            "bright" -> showBright = true
            "mute" -> finish(q.label, cmd.run(if (cmd.isMuted()) "unmute" else "mute"))
            else -> finish(q.label, cmd.run(q.id))
        }
    }

    Column(Modifier.fillMaxSize().background(Cream).statusBarsPadding()) {
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> Home(name, listening, partial, status, said, results, ::talk, ::quick)
                1 -> HistoryScreen(history) { store.clear(); history = store.history() }
                else -> SettingsScreen(name) { name = it; store.name = it }
            }
        }
        TabBar(tab) { tab = it }
    }

    if (showApps) {
        val apps = remember { cmd.apps() }
        AlertDialog(
            onDismissRequest = { showApps = false },
            confirmButton = { TextButton({ showApps = false }) { Text("Close", color = Brown) } },
            title = { Text("Open app") },
            text = {
                LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    items(apps) { a ->
                        Text(
                            a.label,
                            Modifier.fillMaxWidth().clickable {
                                showApps = false
                                finish("Open ${a.label}", listOf(if (cmd.launch(a.pkg)) Action("${a.label} opened", true) else Action("Can't open ${a.label}", false)))
                            }.padding(vertical = 12.dp),
                            color = Ink
                        )
                    }
                }
            },
            containerColor = Color.White
        )
    }

    if (showBright) {
        var v by remember { mutableStateOf(50f) }
        AlertDialog(
            onDismissRequest = { showBright = false },
            confirmButton = { TextButton({ showBright = false }) { Text("Close", color = Brown) } },
            title = { Text("Brightness ${v.roundToInt()}%") },
            text = {
                Slider(
                    value = v,
                    onValueChange = { v = it },
                    onValueChangeFinished = {
                        val n = v.roundToInt()
                        finish("Brightness $n%", cmd.run("brightness $n"))
                    },
                    valueRange = 0f..100f,
                    colors = SliderDefaults.colors(thumbColor = Brown, activeTrackColor = Brown, inactiveTrackColor = Sand2)
                )
            },
            containerColor = Color.White
        )
    }
}

private fun greeting(): String {
    val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when {
        h < 5 -> "Good night"
        h < 12 -> "Good morning"
        h < 18 -> "Good afternoon"
        else -> "Good evening"
    }
}

@Composable
fun Home(
    name: String, listening: Boolean, partial: String, status: String,
    said: String, results: List<Action>, onTalk: () -> Unit, onQuick: (Quick) -> Unit
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(top = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
            Text(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()), fontSize = 14.sp, color = Muted)
            Text("${greeting()}, $name", fontSize = 28.sp, fontWeight = FontWeight.SemiBold, color = Ink)
            Text(Config.CONNECTION_LABEL, fontSize = 15.sp, color = Muted, modifier = Modifier.padding(top = 4.dp))
        }
        Spacer(Modifier.height(32.dp))
        Orb(listening, onTalk)
        Spacer(Modifier.height(12.dp))
        Text(
            when {
                listening -> partial.ifBlank { "Listening..." }
                status.isNotBlank() -> status
                else -> "Tap the orb and speak"
            },
            fontSize = 15.sp, color = Muted, textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 24.dp)
        )
        if (said.isNotBlank()) {
            Spacer(Modifier.height(16.dp))
            Column(
                Modifier.padding(horizontal = 20.dp).fillMaxWidth()
                    .background(Color.White, RoundedCornerShape(22.dp)).padding(16.dp)
            ) {
                Text("You said", fontSize = 13.sp, color = Muted)
                Text(said, fontSize = 17.sp, color = Ink)
                results.forEach { r ->
                    Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            if (r.ok) Icons.Outlined.CheckCircle else Icons.Outlined.ErrorOutline,
                            contentDescription = null, tint = if (r.ok) Brown else Muted, modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(r.text, fontSize = 15.sp, color = Ink)
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
        Text("Quick commands", fontSize = 14.sp, color = Muted, modifier = Modifier.align(Alignment.Start).padding(start = 20.dp))
        Spacer(Modifier.height(8.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(QUICK) { q ->
                Column(
                    Modifier.width(96.dp).height(84.dp).clip(RoundedCornerShape(22.dp)).background(Color.White).clickable { onQuick(q) },
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                ) {
                    Icon(q.icon, contentDescription = null, tint = Brown, modifier = Modifier.size(26.dp))
                    Spacer(Modifier.height(6.dp))
                    Text(q.label, fontSize = 13.sp, color = Ink)
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun Orb(listening: Boolean, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "orb")
    val pulse by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Restart),
        label = "pulse"
    )
    Box(
        Modifier.size(240.dp)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
            .semantics { contentDescription = "Talk to Vox" }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val r = size.minDimension / 2f
            drawCircle(Sand1, r, c)
            drawCircle(Sand2, r * 0.72f, c)
            if (listening) drawCircle(Tan.copy(alpha = 0.4f * (1f - pulse)), r * 0.46f + r * 0.5f * pulse, c)
            drawCircle(Color.White, r * 0.46f, c)
            val m = r * 0.46f * 2f * 0.62f
            val s = m / 40f
            val o = Offset(c.x - m / 2f, c.y - m / 2f)
            drawCircle(Brown, 3.5f * s, Offset(o.x + 20f * s, o.y + 7f * s))
            fun bar(x: Float, y: Float, w: Float, h: Float, col: Color) =
                drawRoundRect(col, Offset(o.x + x * s, o.y + y * s), Size(w * s, h * s), CornerRadius(w * s / 2f))
            bar(9f, 22f, 6f, 12f, Tan)
            bar(17f, 14f, 6f, 20f, Brown)
            bar(25f, 19f, 6f, 15f, Tan)
        }
    }
}

@Composable
fun HistoryScreen(history: List<Entry>, onClear: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("History", fontSize = 28.sp, fontWeight = FontWeight.SemiBold, color = Ink)
            if (history.isNotEmpty()) TextButton(onClear) { Text("Clear", color = Brown) }
        }
        Spacer(Modifier.height(12.dp))
        if (history.isEmpty()) {
            Text("No commands yet", color = Muted, fontSize = 15.sp)
        } else {
            val fmt = remember { SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()) }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(history) { e ->
                    Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(20.dp)).padding(14.dp)) {
                        Text(fmt.format(Date(e.time)), fontSize = 12.sp, color = Muted)
                        Text(e.said, fontSize = 16.sp, color = Ink)
                        e.results.forEach { Text(it, fontSize = 14.sp, color = Muted) }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(name: String, onName: (String) -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(o)
        onDispose { owner.lifecycle.removeObserver(o) }
    }
    val fresh = tick >= 0
    val micOk = fresh && ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    val writeOk = fresh && Settings.System.canWrite(ctx)
    val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    val cn = ComponentName(ctx, VoxAdmin::class.java)
    val adminOk = fresh && dpm.isAdminActive(cn)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("Settings", fontSize = 28.sp, fontWeight = FontWeight.SemiBold, color = Ink)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(value = name, onValueChange = onName, label = { Text("Your name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(20.dp))
        PermRow("Microphone", micOk) {
            ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        PermRow("Change system settings (brightness)", writeOk) {
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        PermRow("Device admin (lock screen)", adminOk) {
            ctx.startActivity(
                Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, cn)
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Vox needs this only to lock the screen on command.")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
        Spacer(Modifier.height(16.dp))
        Text("Say or tap: open an app, volume 40, brightness 70, flashlight on, lock, Wi-Fi, Bluetooth. Join commands with \"and\".", fontSize = 14.sp, color = Muted)
    }
}

@Composable
private fun PermRow(label: String, granted: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp).background(Color.White, RoundedCornerShape(18.dp)).padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, fontSize = 15.sp, color = Ink)
            Text(if (granted) "Allowed" else "Not allowed", fontSize = 13.sp, color = Muted)
        }
        if (!granted) Button(onClick, colors = ButtonDefaults.buttonColors(containerColor = Brown)) { Text("Allow") }
    }
}

@Composable
fun TabBar(selected: Int, onSelect: (Int) -> Unit) {
    val tabs = listOf(Triple("Home", Icons.Outlined.Home, 0), Triple("History", Icons.Outlined.History, 1), Triple("Settings", Icons.Outlined.Settings, 2))
    Row(
        Modifier.navigationBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp).fillMaxWidth().height(56.dp)
            .background(Color.White, RoundedCornerShape(28.dp)).padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically
    ) {
        tabs.forEach { (label, icon, i) ->
            if (i == selected) {
                Row(
                    Modifier.clip(RoundedCornerShape(20.dp)).background(Cream).padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(icon, contentDescription = label, tint = Ink, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(label, fontSize = 14.sp, color = Ink)
                }
            } else {
                Icon(icon, contentDescription = label, tint = Muted, modifier = Modifier.size(24.dp).clickable { onSelect(i) })
            }
        }
    }
}
