package com.vox.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Entry(val time: Long, val said: String, val results: List<String>)

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("vox", Context.MODE_PRIVATE)

    var name: String
        get() = sp.getString("name", "Miron") ?: "Miron"
        set(v) { sp.edit().putString("name", v).apply() }

    fun history(): List<Entry> {
        val arr = JSONArray(sp.getString("history", "[]"))
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val r = o.getJSONArray("r")
            Entry(o.getLong("t"), o.getString("s"), (0 until r.length()).map { r.getString(it) })
        }
    }

    fun add(e: Entry) {
        val list = (listOf(e) + history()).take(50)
        val arr = JSONArray()
        list.forEach { x ->
            arr.put(JSONObject().put("t", x.time).put("s", x.said).put("r", JSONArray(x.results)))
        }
        sp.edit().putString("history", arr.toString()).apply()
    }

    fun clear() { sp.edit().remove("history").apply() }
}
