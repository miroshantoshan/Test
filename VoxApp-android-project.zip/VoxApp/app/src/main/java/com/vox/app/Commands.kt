package com.vox.app

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

data class Action(val text: String, val ok: Boolean)
data class AppInfo(val label: String, val pkg: String)

class Commands(private val ctx: Context) {
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var torchOn = false

    fun run(raw: String): List<Action> =
        raw.lowercase(Locale.getDefault())
            .split(Regex("\\s+(and|then|и|потом|затем)\\s+"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .map { one(it) }

    fun isMuted(): Boolean = audio.isStreamMute(AudioManager.STREAM_MUSIC)

    fun apps(): List<AppInfo> {
        val pm = ctx.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(q, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    fun launch(pkg: String): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        go(i)
        return true
    }

    private fun go(i: Intent) { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    private fun has(s: String, vararg w: String) = w.any { s.contains(it) }

    private fun num(s: String): Int? = Regex("\\d{1,3}").find(s)?.value?.toInt()?.coerceIn(0, 100)

    private fun one(s: String): Action = try {
        dispatch(s)
    } catch (e: Exception) {
        Action("Failed: ${e.message ?: s}", false)
    }

    private fun dispatch(s: String): Action {
        val open = Regex("^(open|launch|start|открой|запусти)\\s+(.+)$").find(s)
        return when {
            has(s, "unmute", "включи звук", "верни звук") -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
                Action("Sound on", true)
            }
            has(s, "mute", "без звука", "выключи звук", "отключи звук") -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                Action("Sound muted", true)
            }
            has(s, "volume", "громкость", "louder", "quieter", "громче", "тише") -> volume(s)
            has(s, "brightness", "яркость", "brighter", "dimmer", "ярче", "темнее") -> brightness(s)
            has(s, "flashlight", "torch", "фонарик", "фонарь") -> flashlight(s)
            has(s, "wifi", "wi-fi", "wi fi", "вай фай", "вайфай") -> {
                go(if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) else Intent(Settings.ACTION_WIFI_SETTINGS))
                Action("Wi-Fi panel opened", true)
            }
            has(s, "bluetooth", "блютуз", "блютус") -> {
                go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                Action("Bluetooth settings opened", true)
            }
            has(s, "unlock", "разблокируй") -> Action("Vox can't unlock the phone", false)
            has(s, "lock", "заблокируй", "блокировка") -> lock()
            has(s, "what time", "time is it", "который час", "сколько времени") ->
                Action("It's " + DateFormat.getTimeInstance(DateFormat.SHORT).format(Date()), true)
            has(s, "settings", "настройки") -> {
                go(Intent(Settings.ACTION_SETTINGS))
                Action("Settings opened", true)
            }
            open != null -> openApp(open.groupValues[2])
            else -> Action("Not supported yet: \"$s\"", false)
        }
    }

    private fun volume(s: String): Action {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val n = num(s)
        return when {
            n != null -> {
                audio.setStreamVolume(AudioManager.STREAM_MUSIC, (n * max / 100.0).roundToInt(), AudioManager.FLAG_SHOW_UI)
                Action("Volume set to $n%", true)
            }
            has(s, "down", "lower", "quieter", "тише", "уменьши", "меньше", "ниже") -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                Action("Volume down", true)
            }
            has(s, "up", "louder", "громче", "увеличь", "больше", "выше", "прибавь") -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                Action("Volume up", true)
            }
            else -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI)
                Action("Volume panel opened", true)
            }
        }
    }

    private fun brightness(s: String): Action {
        if (!Settings.System.canWrite(ctx)) {
            go(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")))
            return Action("Allow Vox to change system settings, then repeat", false)
        }
        val cr = ctx.contentResolver
        val cur = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128)
        val n = num(s)
        val target = when {
            n != null -> n * 255 / 100
            has(s, "brighter", "ярче", "increase", "up") -> cur + 40
            has(s, "dimmer", "темнее", "decrease", "down", "lower") -> cur - 40
            else -> return Action("Say a level, for example: brightness 60", false)
        }.coerceIn(5, 255)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, target)
        return Action("Brightness ${target * 100 / 255}%", true)
    }

    private fun flashlight(s: String): Action {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return Action("This phone has no flashlight", false)
        val on = when {
            has(s, " off", "выключи", "погаси") -> false
            has(s, " on", "включи") -> true
            else -> !torchOn
        }
        cm.setTorchMode(id, on)
        torchOn = on
        return Action(if (on) "Flashlight on" else "Flashlight off", true)
    }

    private fun lock(): Action {
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val cn = ComponentName(ctx, VoxAdmin::class.java)
        return if (dpm.isAdminActive(cn)) {
            dpm.lockNow()
            Action("Phone locked", true)
        } else {
            go(
                Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, cn)
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Vox needs this only to lock the screen on command.")
            )
            Action("Enable Vox as device admin, then repeat", false)
        }
    }

    private fun openApp(raw: String): Action {
        val name = raw.trim().removeSuffix(" app").removeSuffix(" приложение").trim()
        val list = apps()
        val hit = list.firstOrNull { it.label.lowercase() == name }
            ?: list.firstOrNull { it.label.lowercase().startsWith(name) }
            ?: list.firstOrNull { it.label.lowercase().contains(name) }
            ?: return Action("App \"$name\" not found", false)
        return if (launch(hit.pkg)) Action("${hit.label} opened", true) else Action("Can't open ${hit.label}", false)
    }
}
