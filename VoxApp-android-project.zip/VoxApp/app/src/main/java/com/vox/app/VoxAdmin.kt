package com.vox.app

import android.app.admin.DeviceAdminReceiver

class VoxAdmin : DeviceAdminReceiver()
